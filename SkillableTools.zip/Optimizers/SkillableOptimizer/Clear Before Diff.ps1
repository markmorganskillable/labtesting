Get-EventLog -LogName * | ForEach { Clear-EventLog $_.Log }

REG.EXE delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f 

& "C:\Program Files\Bginfo\Bginfo64.exe" "C:\Program Files\BGInfo\Blank.bgi" /timer:0 /silent /nolicprompt

Shutdown -t 5 -S; Remove-Item (Get-PSReadlineOption).HistorySavePath

 