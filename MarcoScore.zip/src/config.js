/*
 * File: config.js
 * Version: 2025-04-10_12:30:00
 * Description: This module manages the configuration for the Scoreboard application by loading and 
 *              saving settings from config.json. It provides a centralized config object with 
 *              defaults for game duration, server port, admin password, and logging verbosity. 
 *              The config is loaded asynchronously at startup and can be updated via the admin 
 *              interface or CLI overrides, with changes persisted to disk. A guard ensures the 
 *              config is loaded only once, preventing redundant file reads across multiple 
 *              requiring modules.
 */

const fs = require('fs').promises;  // Async file system operations
const path = require('path');       // Utility for file path manipulation

// Define the path to config.json in the root directory
const CONFIG_PATH = path.join(__dirname, '../config.json');

// Default configuration values if config.json is missing or invalid
const DEFAULT_CONFIG = {
    defaultGameTime: 300,           // Default game duration in seconds (5 minutes)
    port: 3000,                     // Default server port
    adminPassword: 'Passw0rd',      // Default admin password
    verboseConsoleLogging: true,    // Enable verbose server-side logging by default
    verboseClientLogging: true      // Enable verbose client-side logging by default
};

// Initialize config as an empty object—populated by loadConfig
let config = {};

// Flag to prevent multiple loads of config.json
let isLoaded = false;

// Asynchronously load configuration from config.json
async function loadConfig() {
    // If already loaded, return the cached config to avoid redundant file reads
    if (isLoaded) {
        console.log('Config already loaded:', config);
        return config;
    }
    
    // Attempt to read and parse config.json
    try {
        const configData = await fs.readFile(CONFIG_PATH, 'utf8');    // Read file as UTF-8 string
        const parsedConfig = JSON.parse(configData);                  // Parse JSON into object
        config = { ...DEFAULT_CONFIG, ...parsedConfig };              // Merge defaults with file data
        console.log('Loaded config from file:', config);              // Log successful load
    } catch (error) {
        // If file read or parsing fails, use defaults and save them
        console.log('No config file found or error parsing, using defaults:', DEFAULT_CONFIG);
        config = { ...DEFAULT_CONFIG };                               // Set config to defaults
        await saveConfig();                                           // Persist defaults to disk
    }
    
    // Mark config as loaded to prevent future redundant calls
    isLoaded = true;
    return config;                                                    // Return loaded config
}

// Asynchronously save the current config to config.json
async function saveConfig(newConfig) {
    try {
        // Use provided config or current config if none supplied
        config = newConfig || config;
        await fs.writeFile(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8'); // Write formatted JSON
        console.log('Config saved to file:', config);                 // Log successful save
    } catch (error) {
        console.error('Error saving config:', error);                 // Log any save errors
    }
}

// Export config accessors and functions
module.exports = {
    // Getter for config—ensures modules access the loaded state
    get config() { return config; },
    
    // Expose loadConfig for explicit loading (e.g., by server.js)
    loadConfig,
    
    // Expose saveConfig with optional new config parameter
    saveConfig: (newConfig) => saveConfig(newConfig)
};