const socket = io();

function joinScoreboard(gameID) {
    socket.emit('joinScoreboard', gameID);
}

socket.on('update', (scores) => {
    const scoreboard = document.getElementById('scoreboard');
    if (scores.length === 0) {
        scoreboard.innerHTML = '<div class="waiting">Waiting for players...</div>';
    } else {
        scoreboard.innerHTML = scores.map(player => 
            `<div class="player">
                <span>${player.playerName}</span>
                <span>${player.score}</span>
            </div>`
        ).join('');
    }
});

function submitScore(gameID, playerName, scoreAdd) {
    fetch('/submit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ gameID, playerName, scoreAdd })
    })
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));
}