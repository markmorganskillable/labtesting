/*
 * File: viewer.js
 * Version: 2025-04-10_14:30:00
 * Description: This client-side script powers the Scoreboard application's viewer page, managing 
 *              real-time updates and user interactions via Socket.IO. It handles the display of 
 *              scoreboard data, timers, and banner messages, supports manual updates and speed 
 *              adjustments, and applies animations for score changes and game events like confetti. 
 *              The script runs in the browser, connecting to the server to join a specific game, 
 *              receive updates, and submit scores, with configurable verbose logging controlled 
 *              by server settings.
 */

// Establish Socket.IO connection to the server
const socket = io();

// Extract gameID from the URL path (e.g., /scoreboard/ABC123 -> ABC123)
const gameID = window.location.pathname.split('/').pop();

// Set the gameID display in the HTML
document.getElementById('gameIDDisplay').textContent = gameID;

// Animation timing constants in milliseconds
const FADE_IN_SPEED = 2000;    // Duration for new player fade-in animation
const SLIDE_SPEED = 500;       // Duration for player position slide animation
const ROW_HEIGHT = 54;         // Height of each player row in pixels for slide calculations

// Global flag for verbose client-side logging, updated by server
let VERBOSE_CLIENT_LOGGING = true;

// Inject CSS rules dynamically for animation durations
document.styleSheets[0].insertRule(
    `.new-player { animation-duration: ${FADE_IN_SPEED / 1000}s; }`, // Fade-in for new players
    0
);
document.styleSheets[0].insertRule(
    `.player { transition-duration: ${SLIDE_SPEED / 1000}s; }`,      // Slide transition for position changes
    1
);

// Global state variables
let currentScores = [];        // Current scoreboard data
let gameEnded = false;         // Flag to disable updates post-game
let timeLeft = null;           // Remaining game time in seconds
let timerInterval = null;      // Interval ID for timer updates
let bannerQueue = [];          // Queue for banner messages to prevent overlap
let isBannerPlaying = false;   // Flag to track active banner animation

// Logging function gated by verboseClientLogging config
function log(...args) {
    if (VERBOSE_CLIENT_LOGGING) console.log(...args);
}

// Convert speed selection (in seconds) to milliseconds
function speedToMs(speed) {
    speed = parseInt(speed);   // Parse speed value from string
    return speed === 0 ? 0 : speed * 1000; // Return 0 for manual, else seconds to ms
}

// Start the local timer with initial seconds
function startLocalTimer(secondsLeft) {
    if (timerInterval) clearInterval(timerInterval); // Clear existing timer
    timeLeft = secondsLeft;                          // Set initial time
    updateTimerDisplay(timeLeft);                    // Display initial time
    timerInterval = setInterval(() => {              // Start countdown interval
        if (!gameEnded && timeLeft > 0) {            // Continue if game active and time remains
            timeLeft--;                              // Decrement time
            updateTimerDisplay(timeLeft);            // Update display
        } else if (timeLeft <= 0) {                  // Stop when time runs out
            clearInterval(timerInterval);
            timerInterval = null;
        }
    }, 1000);                                        // Run every second
    log('Timer started with:', secondsLeft);
}

// Update the timer display in the UI
function updateTimerDisplay(seconds) {
    const timerElement = document.getElementById('timer'); // Get timer element
    if (seconds > 0) {                                    // If time remains
        timerElement.textContent = `⏰ Time Left: ${formatTime(seconds)}`; // Show time with clock icon
        timerElement.className = seconds <= 30 ? 'timer-low' : seconds <= 120 ? 'timer-mid' : 'timer-high'; // Color based on time
    } else {                                              // If time’s up
        timerElement.textContent = '⏰ Time Left: 0:00';  // Show zero time
        timerElement.className = 'timer-low';             // Red color
    }
    log('Timer display updated to:', timerElement.textContent);
}

// Toggle visibility of the widget menu
function toggleWidget(event) {
    event.stopPropagation();                              // Prevent event bubbling
    const content = document.querySelector('.widget-content'); // Get widget content
    content.style.display = content.style.display === 'none' ? 'flex' : 'none'; // Toggle visibility
}

// Hide widget menu when clicking outside
function hideWidget(event) {
    const content = document.querySelector('.widget-content'); // Get widget content
    const toggle = document.querySelector('.widget-toggle');   // Get toggle button
    if (!content.contains(event.target) && !toggle.contains(event.target)) { // If click outside
        content.style.display = 'none';                   // Hide widget
    }
}

// Add click listener to hide widget on outside clicks
document.addEventListener('click', hideWidget);

// Add a banner message to the queue
function addBannerMessage(message) {
    bannerQueue.push(message);                            // Add message to queue
    playNextBanner();                                     // Start or continue playback
}

// Play the next banner message in the queue
function playNextBanner() {
    if (isBannerPlaying || bannerQueue.length === 0) return; // Skip if playing or queue empty

    isBannerPlaying = true;                               // Mark as playing
    const message = bannerQueue.shift();                  // Get next message
    const bannerContent = document.querySelector('.banner-content'); // Get banner element

    bannerContent.classList.add('hidden');                // Fade out current message
    setTimeout(() => {                                    // After fade-out
        bannerContent.textContent = message;              // Set new message
        bannerContent.classList.remove('hidden');         // Fade in
        bannerContent.classList.add('new-message');       // Trigger fade-in and pulse
        log('Banner updated with:', message);

        setTimeout(() => {                                // After animation (3s)
            bannerContent.classList.remove('new-message'); // Reset animation
            isBannerPlaying = false;                      // Mark as done
            setTimeout(playNextBanner, 1000);             // 1s delay before next
        }, 3000);                                         // Animation duration
    }, 500);                                              // Fade-out duration
}

// Join a scoreboard room via Socket.IO
function joinScoreboard(gameID) {
    socket.emit('joinScoreboard', gameID);                // Request to join game room
    const initialSpeed = speedToMs(document.getElementById('speedSelect').value); // Get initial speed
    socket.emit('setUpdateSpeed', { gameID, speed: initialSpeed }); // Set update speed
    log('Joined scoreboard and set initial speed:', gameID, initialSpeed);
}

// Wait for DOM to load before joining scoreboard
document.addEventListener('DOMContentLoaded', () => {
    joinScoreboard(gameID);
});

// Submit a score to the server
function submitScore(gameID, playerName, scoreAdd) {
    if (gameEnded) return;                                // Skip if game over
    fetch('/submit', {                                    // POST request to server
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ gameID, playerName, scoreAdd }) // Send score data
    })
    .then(response => response.json())                    // Parse JSON response
    .then(data => console.log(data))                      // Log success
    .catch(error => console.error('Error:', error));      // Log errors
}

// Event listener for manual update button
document.getElementById('updateBtn').addEventListener('click', () => {
    if (gameEnded) return;                                // Skip if game over
    socket.emit('getScores', gameID);                     // Request manual update
    log('Manual update requested for:', gameID);
});

// Event listener for speed selection change
document.getElementById('speedSelect').addEventListener('change', (e) => {
    if (gameEnded) return;                                // Skip if game over
    const speed = speedToMs(e.target.value);              // Convert speed to ms
    socket.emit('setUpdateSpeed', { gameID, speed });     // Update server speed
    log('Speed changed to:', speed, 'ms');
});

// Handle server update events
socket.on('update', (data) => {
    VERBOSE_CLIENT_LOGGING = data.verboseClientLogging;   // Update logging flag from server
    log('Received update data:', JSON.stringify(data));

    // Always update timer if present
    if (data.timer && data.timeLeft !== undefined && !gameEnded) {
        startLocalTimer(data.timeLeft);                   // Start or sync timer
    } else if (!gameEnded) {
        document.getElementById('timer').textContent = ''; // Clear timer if no time
        if (timerInterval) clearInterval(timerInterval);  // Stop timer
        timerInterval = null;
        log('No timer or game ended, cleared timer');
    }

    const scoreboard = document.getElementById('scoreboard'); // Get scoreboard element
    const scoresChanged = JSON.stringify(data.scores) !== JSON.stringify(currentScores); // Check for score changes
    
    // Skip scoreboard update if no changes and name matches
    if (!scoresChanged && document.getElementById('scoreboardName').textContent === data.name && !gameEnded) {
        log('No changes detected, skipping scoreboard update');
        return;
    }

    log('Updating scoreboard with new data');
    const oldScores = new Map(currentScores.map(p => [p.playerName, { score: p.score, position: p.position }])); // Map old scores
    currentScores = data.scores.slice();                  // Update current scores

    const speedSelect = document.getElementById('speedSelect'); // Get speed select element
    const currentSpeed = speedSelect.value;               // Preserve current speed selection

    document.getElementById('scoreboardName').textContent = data.name || 'Scoreboard'; // Update scoreboard name
    log('Scoreboard name set to:', data.name || 'Scoreboard');

    // Handle empty scoreboard
    if (!data.scores || data.scores.length === 0) {
        addBannerMessage('Waiting for players...');       // Show waiting message
        scoreboard.innerHTML = '';                        // Clear scoreboard
        log('Scoreboard empty, showing waiting message');
    } else {
        // Map existing players in the DOM
        const existingPlayers = new Map();
        Array.from(scoreboard.getElementsByClassName('player')).forEach((player) => {
            const name = player.querySelector('span:nth-child(2)').textContent; // Player name
            const score = parseInt(player.querySelector('span:last-child').textContent || '0'); // Player score
            const positionText = player.querySelector('span:first-child').textContent || '0'; // Player position
            const oldPosition = parseInt(positionText) || 0;
            existingPlayers.set(name, { score, element: player, oldPosition }); // Store player data
        });
        log('Existing players mapped:', Array.from(existingPlayers.keys()));

        const fragment = document.createDocumentFragment(); // Batch DOM updates
        const updatedElements = new Map();                  // Track updated player elements

        // Process each player in the new scores
        data.scores.forEach((playerData) => {
            const { playerName, score, position } = playerData;
            if (!playerName || score === undefined || position === undefined) { // Validate data
                log('Invalid player data:', playerData);
                return;
            }

            let playerElement;
            const existing = existingPlayers.get(playerName); // Check if player exists

            if (existing) {                                 // Update existing player
                playerElement = existing.element;
                const oldScore = existing.score;
                const oldPosition = existing.oldPosition;
                log(`Updating ${playerName}: oldScore=${oldScore}, newScore=${score}, oldPosition=${oldPosition}, newPosition=${position}`);
                playerElement.querySelector('span:first-child').textContent = `${position}.`; // Update position
                playerElement.querySelector('span:last-child').textContent = score; // Update score
                
                // Apply score change animations
                if (oldScore !== score) {
                    playerElement.classList.remove('score-increase', 'score-decrease'); // Clear old animations
                    void playerElement.offsetWidth;          // Trigger reflow
                    if (score > oldScore) {
                        playerElement.classList.add('score-increase'); // Green pulse for increase
                    } else if (score < oldScore) {
                        playerElement.classList.add('score-decrease'); // Red pulse for decrease
                    }
                    setTimeout(() => {                       // Remove animation after 1s
                        playerElement.classList.remove('score-increase', 'score-decrease');
                    }, 1000);
                }
                
                // Calculate slide offset for position change
                const offset = (oldPosition - position) * ROW_HEIGHT;
                log(`${playerName}: Moving from position ${oldPosition} to ${position}, offset ${offset}px`);
                playerElement.style.transform = `translateY(${offset}px)`; // Apply slide
                playerElement.classList.toggle('top', position === 1); // Highlight top player
                existingPlayers.delete(playerName);         // Remove from existing map
            } else {                                        // Add new player
                playerElement = document.createElement('div');
                playerElement.className = 'player new-player'; // New player class for fade-in
                playerElement.innerHTML = `<span>${position}.</span><span>${playerName}</span><span>${score}</span>`; // Player HTML
                playerElement.style.transform = 'translateY(0)'; // Initial position
                playerElement.classList.toggle('top', position === 1); // Highlight if top
                log(`${playerName}: Added as new player at position ${position}`);
            }
            updatedElements.set(playerName, playerElement); // Store updated element
        });

        // Append updated elements in order
        data.scores.forEach(playerData => {
            const playerElement = updatedElements.get(playerData.playerName);
            if (playerElement) {
                fragment.appendChild(playerElement);
            }
        });

        // Remove players no longer in scores
        existingPlayers.forEach(player => {
            log(`Removing player: ${player.element.querySelector('span:nth-child(2)').textContent}`);
            player.element.remove();
        });

        scoreboard.innerHTML = '';                         // Clear current scoreboard
        scoreboard.appendChild(fragment);                  // Append new scoreboard
        log('Scoreboard DOM updated with elements:', Array.from(scoreboard.children).map(el => el.outerHTML));

        // Animate position changes
        requestAnimationFrame(() => {
            Array.from(scoreboard.getElementsByClassName('player')).forEach(player => {
                player.offsetHeight;                       // Trigger reflow
                player.style.transition = `transform ${SLIDE_SPEED / 1000}s ease`; // Apply slide transition
                player.style.transform = 'translateY(0)';  // Slide to final position
            });

            setTimeout(() => {                             // After animations
                Array.from(scoreboard.getElementsByClassName('new-player')).forEach(player => {
                    player.classList.remove('new-player'); // Remove fade-in class
                });
                Array.from(scoreboard.getElementsByClassName('player')).forEach(player => {
                    player.style.transition = '';          // Clear transition
                    player.style.transform = '';           // Clear transform
                });
                log('Animations complete, styles reset. Current scoreboard:', Array.from(scoreboard.children).map(el => el.outerHTML));
            }, FADE_IN_SPEED);                            // Match fade-in duration
        });
    }

    speedSelect.value = currentSpeed;                     // Restore speed selection
});

// Handle incoming banner messages
socket.on('bannerMessage', (message) => {
    addBannerMessage(message);                            // Add to queue for display
});

// Deprecated timer update handler (kept for compatibility)
socket.on('timerUpdate', (timeLeft) => {
    log('Received deprecated timerUpdate:', timeLeft);    // Log for debugging
});

// Handle game over event
socket.on('gameOver', () => {
    gameEnded = true;                                     // Mark game as ended
    document.getElementById('updateBtn').disabled = true; // Disable update button
    document.getElementById('speedSelect').disabled = true; // Disable speed select
    document.getElementById('timer').textContent = '⏰ Time Left: 0:00'; // Show zero time
    if (timerInterval) clearInterval(timerInterval);      // Stop timer
    timerInterval = null;
    log('Game over event received, updates stopped');
});

// Handle confetti event for winners
socket.on('confetti', () => {
    confetti({                                            // Trigger first confetti burst
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
    });
    setTimeout(() => {                                    // Second burst after 0.5s
        confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 }
        });
    }, 500);
});

// Handle scoreboard not found event
socket.on('scoreboardNotFound', () => {
    gameEnded = true;                                     // Mark as ended
    addBannerMessage('Scoreboard Not Found');             // Notify user
    document.getElementById('scoreboard').innerHTML = ''; // Clear scoreboard
    document.getElementById('updateBtn').disabled = true; // Disable update button
    document.getElementById('speedSelect').disabled = true; // Disable speed select
    log('Scoreboard not found or ended');
});

// Format seconds into MM:SS string
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);             // Calculate minutes
    const secs = seconds % 60;                            // Remaining seconds
    return `${minutes}:${secs < 10 ? '0' : ''}${secs}`;  // Pad seconds with zero if needed
}