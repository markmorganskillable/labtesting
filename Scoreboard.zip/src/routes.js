/*
 * File: routes.js
 * Version: 2025-04-10_13:00:00
 * Description: This module defines the HTTP routes for the Scoreboard application, handling client 
 *              requests for game creation, viewing, admin access, and API interactions. It sets up 
 *              endpoints for the home page, scoreboard views, game initialization (including a 
 *              sample game), admin login and configuration, and score submissions. Routes leverage 
 *              Express for request handling, integrate with Socket.IO for real-time updates, and 
 *              use the gameLogic module for core functionality. Configuration is sourced from 
 *              config.json via the config module, and logging is toggleable for verbosity control.
 */

const path = require('path');           // Utility for file path manipulation
const configModule = require('./config'); // Configuration management module

// Logging function gated by verboseConsoleLogging config
function log(...args) {
    if (configModule.config.verboseConsoleLogging) console.log(...args);
}

// Main route setup function, accepting dependencies as arguments
function setupRoutes(app, io, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, gameLogic, configModule, getAdminPassword, socketBroadcast) {
    // Route: Home page - serves index.html
    app.get('/', (req, res) => {
        res.sendFile(path.join(__dirname, '../public', 'index.html')); // Serve static home page
    });

    // Route: Scoreboard view - serves viewer.html for a specific gameID
    app.get('/scoreboard/:gameID', (req, res) => {
        const gameID = req.params.gameID.toUpperCase();               // Normalize gameID to uppercase
        res.sendFile(path.join(__dirname, '../public', 'viewer.html')); // Serve viewer page
    });

    // Route: Create a new scoreboard - handles game initialization
    app.get('/create', (req, res) => {
        const gameID = req.query.gameID ? req.query.gameID.toUpperCase() : gameLogic.generateHexId(); // Use provided gameID or generate one
        const name = req.query.name ? decodeURIComponent(req.query.name) : 'Scoreboard';             // Use provided name or default
        const gameTimerSeconds = req.query.gameTimer ? parseInt(req.query.gameTimer, 10) : configModule.config.defaultGameTime; // Timer from query or config

        // Reset Sample Game if it’s being recreated
        if (gameID === 'SAMPLEGAME' && scoreboards.has(gameID)) {
            log(`Home page resetting Sample Game ${gameID}`);
            sampleGameTimeouts.forEach((timeoutId, key) => {         // Clear all Sample Game timeouts
                if (key.startsWith(gameID)) {
                    clearTimeout(timeoutId);
                    sampleGameTimeouts.delete(key);
                }
            });
            scoreboards.delete(gameID);                              // Remove existing scoreboard
            usedNames.delete(gameID);                                // Clear used names
            if (cleanupTimeouts.has(gameID)) {                       // Clear cleanup timer
                clearTimeout(cleanupTimeouts.get(gameID));
                cleanupTimeouts.delete(gameID);
            }
        }

        // Initialize new scoreboard with provided or default settings
        scoreboards.set(gameID, { 
            scores: new Map(),                                       // Empty scores map
            name,                                                    // Scoreboard name
            gameOver: false,                                         // Game active status
            timer: gameTimerSeconds,                                 // Game duration in seconds
            timerEnd: gameTimerSeconds ? Date.now() + gameTimerSeconds * 1000 : null // End time or null
        });
        usedNames.set(gameID, new Set());                            // Initialize used names set
        gameLogic.scheduleCleanup(gameID, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast); // Schedule cleanup
        if (gameTimerSeconds) gameLogic.startGameTimer(gameID, scoreboards, io, socketBroadcast, sampleGameTimeouts, usedNames, cleanupTimeouts); // Start timer if set
        io.to(gameID).emit('bannerMessage', 'Game has started!');    // Notify clients of game start
        
        // Return JSON for API use or redirect to confirmation page
        if (req.query.json === 'true') {
            return res.json({ gameID });
        }
        res.redirect(`/confirmation?gameID=${gameID}&name=${encodeURIComponent(name)}`);
    });

    // Route: Start or join the Sample Game
    app.get('/start-sample', (req, res) => {
        const gameID = 'SAMPLEGAME';                                 // Fixed ID for Sample Game
        const scoreboard = scoreboards.get(gameID);
        
        // Join existing Sample Game if running
        if (scoreboard && !scoreboard.gameOver) {
            log(`Joining existing running Sample Game ${gameID}`);
            res.redirect(`/scoreboard/${gameID}`);
        } else {
            // Reset existing Sample Game if ended
            if (scoreboards.has(gameID)) {
                log(`Resetting existing Sample Game ${gameID} for new start`);
                sampleGameTimeouts.forEach((timeoutId, key) => {
                    if (key.startsWith(gameID)) {
                        clearTimeout(timeoutId);
                        sampleGameTimeouts.delete(key);
                    }
                });
                scoreboards.delete(gameID);
                usedNames.delete(gameID);
                if (cleanupTimeouts.has(gameID)) {
                    clearTimeout(cleanupTimeouts.get(gameID));
                    cleanupTimeouts.delete(gameID);
                }
            }
            // Start new Sample Game and redirect
            gameLogic.startSampleGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast);
            res.redirect(`/scoreboard/${gameID}`);
        }
    });

    // Route: Confirmation page - serves confirmation.html after game creation
    app.get('/confirmation', (req, res) => {
        res.sendFile(path.join(__dirname, '../public', 'confirmation.html'));
    });

    // Route: Admin login - authenticates admin users
    app.post('/admin/login', (req, res) => {
        const { password } = req.body;                               // Extract password from request body
        const currentAdminPassword = getAdminPassword();             // Get current admin password dynamically
        log('Admin login attempt with password:', password, 'against:', currentAdminPassword);
        
        // Check password match and set session if valid
        if (password === currentAdminPassword) {
            req.session.isAdmin = true;                              // Mark session as admin
            res.status(200).send('OK');                              // Success response
        } else {
            res.status(403).send('Incorrect password');              // Failure response
        }
    });

    // Route: Admin console - serves admin.html for authenticated users
    app.get('/admin', (req, res) => {
        if (!req.session.isAdmin) {                                  // Check admin session
            return res.status(403).send('Unauthorized - Please login'); // Deny if not authenticated
        }
        res.sendFile(path.join(__dirname, '../public', 'admin.html')); // Serve admin page
    });

    // Route: Admin data - provides scoreboard and config data for admin UI
    app.get('/admin/data', async (req, res) => {
        if (!req.session.isAdmin) {
            return res.status(403).json({ error: 'Unauthorized' });  // Deny if not authenticated
        }
        // Build list of current scoreboards with status and time left
        const scoreboardList = Array.from(scoreboards.entries()).map(([id, board]) => ({
            id,
            name: board.name,
            running: !board.gameOver,
            timeLeft: board.timerEnd ? Math.max(0, Math.floor((board.timerEnd - Date.now()) / 1000)) : 0
        }));
        // Return scoreboard list and current config
        res.json({ 
            scoreboards: scoreboardList, 
            config: {
                defaultGameTime: configModule.config.defaultGameTime,
                port: configModule.config.port,
                adminPassword: configModule.config.adminPassword,
                verboseConsoleLogging: configModule.config.verboseConsoleLogging,
                verboseClientLogging: configModule.config.verboseClientLogging
            }
        });
    });

    // Route: Update admin config - saves new config settings
    app.post('/admin/update-config', async (req, res) => {
        if (!req.session.isAdmin) {
            return res.status(403).json({ error: 'Unauthorized' });  // Deny if not authenticated
        }
        const { defaultGameTime, port, adminPassword, verboseConsoleLogging, verboseClientLogging } = req.body; // Extract config updates
        // Update config if values are provided
        if (defaultGameTime !== undefined) configModule.config.defaultGameTime = parseInt(defaultGameTime) || 0;
        if (port !== undefined) configModule.config.port = parseInt(port) || 3000;
        if (adminPassword !== undefined) configModule.config.adminPassword = adminPassword;
        if (verboseConsoleLogging !== undefined) configModule.config.verboseConsoleLogging = verboseConsoleLogging;
        if (verboseClientLogging !== undefined) configModule.config.verboseClientLogging = verboseClientLogging;
        log('Updating config with:', configModule.config);           // Log new config state
        await configModule.saveConfig(configModule.config);          // Persist to config.json
        res.json({ success: true, config: configModule.config });    // Return success and updated config
    });

    // Route: API create - programmatic game creation
    app.post('/api/create', (req, res) => {
        let gameID = req.body.gameID ? req.body.gameID.toUpperCase() : gameLogic.generateHexId(); // Use provided or generated gameID
        const name = req.body.name ? req.body.name.trim() : 'Scoreboard';                         // Use provided or default name
        const gameTimerSeconds = req.body.gameTimer ? parseInt(req.body.gameTimer, 10) * 60 : configModule.config.defaultGameTime; // Convert minutes to seconds

        // Handle Sample Game creation or reuse
        if (gameID === 'SAMPLEGAME') {
            const existingScoreboard = scoreboards.get(gameID);
            if (existingScoreboard && !existingScoreboard.gameOver) {
                log(`API returning existing running Sample Game ${gameID}`);
                return res.json({ gameID });
            }
            if (scoreboards.has(gameID)) {
                log(`API resetting Sample Game ${gameID}`);
                sampleGameTimeouts.forEach((timeoutId, key) => {
                    if (key.startsWith(gameID)) {
                        clearTimeout(timeoutId);
                        sampleGameTimeouts.delete(key);
                    }
                });
                scoreboards.delete(gameID);
                usedNames.delete(gameID);
                if (cleanupTimeouts.has(gameID)) {
                    clearTimeout(cleanupTimeouts.get(gameID));
                    cleanupTimeouts.delete(gameID);
                }
            }
            gameLogic.startSampleGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast);
        } else {
            // Create custom game
            scoreboards.set(gameID, { 
                scores: new Map(), 
                name, 
                gameOver: false, 
                timer: gameTimerSeconds, 
                timerEnd: gameTimerSeconds ? Date.now() + gameTimerSeconds * 1000 : null 
            });
            usedNames.set(gameID, new Set());
            gameLogic.scheduleCleanup(gameID, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast);
            if (gameTimerSeconds) gameLogic.startGameTimer(gameID, scoreboards, io, socketBroadcast, sampleGameTimeouts, usedNames, cleanupTimeouts);
            io.to(gameID).emit('bannerMessage', 'Game has started!');
        }

        log(`API ${gameID === 'SAMPLEGAME' ? 'started or returned' : 'created'} scoreboard with gameID: ${gameID}, name: ${name}, timer: ${gameTimerSeconds}s`);
        res.json({ gameID });                                            // Return gameID in JSON response
    });

    // Route: Submit score - handles player score updates
    app.post('/submit', (req, res) => {
        const { gameID: rawGameID, playerName: rawPlayerName, scoreAdd } = req.body; // Extract request data
        const gameID = rawGameID.toUpperCase();
        
        // Validate required fields
        if (!gameID || scoreAdd === undefined) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        if (!scoreboards.has(gameID) || scoreboards.get(gameID).gameOver) {
            return res.status(404).json({ error: 'Scoreboard not found or has ended' });
        }
        
        const scoreboard = scoreboards.get(gameID);
        let playerName = rawPlayerName ? rawPlayerName.trim() : '';      // Trim provided name or empty
        const isNewPlayer = !playerName || !scoreboard.scores.has(playerName); // New if no name or not in scores
        
        // Generate name if none provided
        if (!playerName) {
            playerName = gameLogic.generateUniqueName(gameID, usedNames);
            log(`Generated unique name ${playerName} for blank playerName submission in ${gameID}`);
        }

        // Update scoreboard with new score
        gameLogic.updateScoreboard(gameID, playerName, scoreAdd, isNewPlayer, scoreboards, io, socketBroadcast);
        res.json({ success: true, playerName });                         // Return success and player name

        // Reset cleanup timer for non-Sample Games
        if (gameID !== 'SAMPLEGAME' && cleanupTimeouts.has(gameID)) {
            clearTimeout(cleanupTimeouts.get(gameID));
            cleanupTimeouts.delete(gameID);
            gameLogic.scheduleCleanup(gameID, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast);
            log(`Reset cleanup timer for scoreboard ${gameID} due to ${isNewPlayer ? 'new player' : 'score update'}`);
        }
    });

    // Route: End game - terminates a specific game via API
    app.post('/api/endgame', (req, res) => {
        const { gameID: rawGameID } = req.body;
        const gameID = rawGameID.toUpperCase();
        
        // Check if game exists
        if (!scoreboards.has(gameID)) {
            return res.status(404).json({ error: 'Scoreboard not found' });
        }
        
        // End the game using gameLogic
        gameLogic.endGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast);
        res.json({ success: true });                                     // Return success response
    });
}

// Export the setupRoutes function for use in server.js
module.exports = setupRoutes;