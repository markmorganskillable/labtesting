/*
 * File: gameLogic.js
 * Version: 2025-04-10_13:30:00
 * Description: This module encapsulates the core game logic for the Scoreboard application, managing 
 *              scoreboard updates, sample game simulation, timer handling, and cleanup scheduling. 
 *              It provides functions to update player scores, start and end games, generate unique 
 *              player names and game IDs, and broadcast real-time updates via Socket.IO. The module 
 *              integrates with configuration settings for logging verbosity and uses in-memory 
 *              data structures for fast game state management. It supports both custom and sample 
 *              games, with features like leader detection, surge notifications, and timed game 
 *              endings with winner announcements.
 */

const names = require('./names.json');        // Predefined names for player generation
const messages = require('./messages.json');  // Message templates for game events
const configModule = require('./config');     // Configuration management module

// Constants for game timeouts
const NON_SAMPLEGAME_TIMEOUT = 1800000;       // 30 minutes in ms for custom game cleanup
const SAMPLE_GAME_DURATION = 300;             // 5 minutes in seconds for Sample Game

// Logging function gated by verboseConsoleLogging config
function log(...args) {
    if (configModule.config.verboseConsoleLogging) console.log(...args);
}

// Select a random message from a category, replacing {player} if provided
function getRandomMessage(type, player, messages) {
    const messageArray = messages[type];                              // Get message array by type
    const msg = messageArray[Math.floor(Math.random() * messageArray.length)]; // Random selection
    return player ? msg.replace('{player}', player) : msg;           // Replace placeholder or return as-is
}

// Generate a random hexadecimal game ID
function generateHexId(length = 8) {
    const chars = '0123456789ABCDEF';                               // Hex character set
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];   // Append random hex digit
    }
    return result;
}

// Generate a unique player name combining phonetic alphabet and animals
function generateUniqueName(gameID, usedNames) {
    const gameUsedNames = usedNames.get(gameID) || new Set();        // Get or init used names set
    let newName;
    let attempts = 0;
    const maxAttempts = 100;                                         // Limit name generation attempts

    do {
        // 10% chance of an Easter egg name
        if (Math.random() < 0.1 && names.easterEggs.length > 0) {
            newName = names.easterEggs[Math.floor(Math.random() * names.easterEggs.length)];
        } else {
            // Combine phonetic word and animal starting with same letter
            const phoneticIndex = Math.floor(Math.random() * names.phoneticAlphabet.length);
            const first = names.phoneticAlphabet[phoneticIndex];
            const letter = first.charAt(0).toUpperCase();
            const animalList = names.animals[letter] || [];
            if (animalList.length === 0) continue;                  // Skip if no animals for letter
            const animal = animalList[Math.floor(Math.random() * animalList.length)];
            newName = `${first} ${animal}`;
        }
        attempts++;
        // Append number if max attempts reached
        if (attempts > maxAttempts) {
            newName = `${newName} ${gameUsedNames.size + 1}`;
            break;
        }
    } while (gameUsedNames.has(newName));                          // Repeat until unique

    gameUsedNames.add(newName);                                    // Add to used names
    usedNames.set(gameID, gameUsedNames);                          // Update map
    return newName;
}

// Update scoreboard with new score or player join
function updateScoreboard(gameID, playerName, scoreAdd, isNewPlayer, scoreboards, io, socketBroadcast) {
    const scoreboard = scoreboards.get(gameID);                    // Get game scoreboard
    const oldScoresArray = Array.from(scoreboard.scores.entries())
        .map(([playerName, score]) => ({ playerName, score }))     // Convert scores to array
        .sort((a, b) => b.score - a.score);                       // Sort by score descending
    let prevScore = null;
    oldScoresArray.forEach((player, index) => {                    // Assign positions, handling ties
        player.position = prevScore === player.score ? oldScoresArray[index - 1].position : index + 1;
        prevScore = player.score;
    });

    const currentScore = scoreboard.scores.get(playerName) || 0;   // Get current score or 0
    scoreboard.scores.set(playerName, currentScore + Number(scoreAdd)); // Update score

    const scoresArray = Array.from(scoreboard.scores.entries())
        .map(([playerName, score]) => ({ playerName, score }))     // New scores array
        .sort((a, b) => b.score - a.score);
    prevScore = null;
    scoresArray.forEach((player, index) => {                       // Assign new positions
        player.position = prevScore === player.score ? scoresArray[index - 1].position : index + 1;
        prevScore = player.score;
    });

    log(`Scores array after update for ${gameID}:`, JSON.stringify(scoresArray));

    // Announce new player join
    if (isNewPlayer) {
        log(`Emitting new player message for ${playerName} in ${gameID}`);
        io.to(gameID).emit('bannerMessage', `${playerName} has joined the game!`);
    }

    // Detect and announce leader changes
    const oldTopScore = oldScoresArray.length > 0 ? oldScoresArray[0].score : -Infinity;
    const newTopScore = scoresArray[0].score;
    const oldLeader = oldScoresArray.length > 0 ? oldScoresArray[0].playerName : null;
    const newLeader = scoresArray[0].playerName;
    const oldLeaders = oldScoresArray.filter(p => p.score === oldTopScore).map(p => p.playerName);
    const newLeaders = scoresArray.filter(p => p.score === newTopScore).map(p => p.playerName);

    if (newTopScore > oldTopScore && newLeader !== oldLeader) {
        log(`New leader detected: ${newLeader} with score ${newTopScore} in ${gameID}`);
        io.to(gameID).emit('bannerMessage', getRandomMessage('leaderMessages', newLeader, messages));
    } else if (newTopScore === oldTopScore && newLeaders.length > oldLeaders.length) {
        const newTiedPlayer = newLeaders.find(p => !oldLeaders.includes(p));
        if (newTiedPlayer) {
            log(`New tie for lead: ${newTiedPlayer} with score ${newTopScore} in ${gameID}`);
            io.to(gameID).emit('bannerMessage', `${newTiedPlayer} has tied for the lead!`);
        }
    }

    // Check for surges and minor position changes
    scoresArray.forEach((player) => {
        const oldPlayer = oldScoresArray.find(p => p.playerName === player.playerName);
        if (oldPlayer && oldPlayer.position - player.position >= 2) {
            log(`Surge detected: ${player.playerName} from ${oldPlayer.position} to ${player.position} in ${gameID}`);
            io.to(gameID).emit('bannerMessage', getRandomMessage('surgeMessages', player.playerName, messages));
        } else if (oldPlayer && oldPlayer.position > player.position && oldPlayer.position - player.position < 2 && Math.random() < 0.3) {
            const funMsg = getRandomMessage('funMessages', null, messages);
            log(`Queueing fun message for position change: ${funMsg} in ${gameID}`);
            setTimeout(() => {                                        // Delay fun message by 3s
                io.to(gameID).emit('bannerMessage', funMsg);
            }, 3000);
        }
    });

    socketBroadcast(gameID, scoreboards, io);                        // Broadcast updated state
}

// Start a Sample Game with simulated players and updates
function startSampleGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast) {
    log('Starting SampleGame with 5-minute timer...');
    const scoreboard = { 
        scores: new Map(),                                          // Empty scores
        name: 'Sample Game',                                        // Fixed name
        gameOver: false,                                            // Active status
        timer: SAMPLE_GAME_DURATION,                                // 5-minute duration
        timerEnd: Date.now() + SAMPLE_GAME_DURATION * 1000          // End time
    };
    scoreboards.set(gameID, scoreboard);                            // Register scoreboard
    usedNames.set(gameID, new Set());                               // Init used names
    log(`Emitting start message for ${gameID}`);
    io.to(gameID).emit('bannerMessage', 'Game has started!');       // Notify clients
    startGameTimer(gameID, scoreboards, io, socketBroadcast, sampleGameTimeouts, usedNames, cleanupTimeouts); // Start timer

    const playerCount = Math.floor(Math.random() * 6) + 5;          // 5-10 players
    let addedPlayers = 0;

    // Recursive function to add simulated players
    function addPlayer() {
        if (addedPlayers < playerCount && !scoreboard.gameOver) {
            const playerName = generateUniqueName(gameID, usedNames); // Generate unique name
            setTimeout(() => {                                       // Delay first player by 1s
                updateScoreboard(gameID, playerName, Math.floor(Math.random() * 50), true, scoreboards, io, socketBroadcast);
            }, addedPlayers === 0 ? 1000 : 0);
            addedPlayers++;
            const nextAdd = Math.random() * 8000 + 2000;             // 2-10s interval
            const timeoutId = setTimeout(addPlayer, nextAdd);        // Schedule next player
            sampleGameTimeouts.set(`${gameID}-add-${addedPlayers}`, timeoutId); // Store timeout
        }
    }

    addPlayer();                                                    // Start adding players

    // Recursive function to simulate score updates
    function updateSampleScore() {
        if (!scoreboard.gameOver) {
            const players = Array.from(scoreboard.scores.keys());
            if (players.length > 0) {
                const randomPlayer = players[Math.floor(Math.random() * players.length)]; // Pick random player
                const scoreAdd = Math.floor(Math.random() * 10) + 1;  // Add 1-10 points
                updateScoreboard(gameID, randomPlayer, scoreAdd, false, scoreboards, io, socketBroadcast);
            }
            const nextUpdate = Math.random() * 4000 + 1000;          // 1-5s interval
            const timeoutId = setTimeout(updateSampleScore, nextUpdate); // Schedule next update
            sampleGameTimeouts.set(`${gameID}-score`, timeoutId);    // Store timeout
        }
    }

    updateSampleScore();                                            // Start score updates
}

// Schedule cleanup for inactive games
function scheduleCleanup(gameID, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast) {
    const cleanupDelay = gameID === 'SAMPLEGAME' ? 300000 : NON_SAMPLEGAME_TIMEOUT; // 5min for Sample, 30min for custom
    const cleanupTimeout = setTimeout(() => endGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast), cleanupDelay);
    cleanupTimeouts.set(gameID, cleanupTimeout);                    // Store cleanup timer
    log(`Set cleanup timer for ${gameID === 'SAMPLEGAME' ? 'SampleGame' : `scoreboard ${gameID}`}: ${cleanupDelay / 60000} minutes`);
}

// Start game timer with warning and end logic
function startGameTimer(gameID, scoreboards, io, socketBroadcast, sampleGameTimeouts, usedNames, cleanupTimeouts) {
    const scoreboard = scoreboards.get(gameID);
    if (!scoreboard || scoreboard.gameOver || !scoreboard.timer) return; // Exit if invalid state

    let hasWarnedYellow = false;                                    // Track yellow warning
    let hasWarnedRed = false;                                       // Track red warning

    // Check timer every second
    const checkEnd = setInterval(() => {
        const now = Date.now();
        const timeLeft = Math.max(0, Math.floor((scoreboard.timerEnd - now) / 1000)); // Remaining seconds
        
        // Yellow warning at 2 minutes
        if (timeLeft <= 120 && !hasWarnedYellow) {
            log(`Emitting warning message for ${gameID}`);
            io.to(gameID).emit('bannerMessage', getRandomMessage('warningMessages', null, messages));
            hasWarnedYellow = true;
        }
        // Red warning at 30 seconds
        if (timeLeft <= 30 && !hasWarnedRed) {
            log(`Emitting urgent message for ${gameID}`);
            io.to(gameID).emit('bannerMessage', getRandomMessage('urgentMessages', null, messages));
            hasWarnedRed = true;
        }
        
        // End game when time’s up
        if (now >= scoreboard.timerEnd) {
            clearInterval(checkEnd);
            endGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast);
        }
    }, 1000);
}

// End a game and announce winners
function endGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast) {
    const scoreboard = scoreboards.get(gameID);
    if (!scoreboard || scoreboard.gameOver) return;                 // Exit if already ended
    scoreboard.gameOver = true;                                     // Mark as ended
    scoreboard.timerEnd = Date.now();                               // Set end time
    log(`Ending game ${gameID}...`);
    io.to(gameID).emit('gameOver');                                 // Notify clients of game over
    
    // Calculate final scores and positions
    const scoresArray = Array.from(scoreboard.scores.entries())
        .map(([playerName, score]) => ({ playerName, score }))
        .sort((a, b) => b.score - a.score);
    let prevScore = null;
    scoresArray.forEach((player, index) => {
        player.position = prevScore === player.score ? scoresArray[index - 1].position : index + 1;
        prevScore = player.score;
    });
    socketBroadcast(gameID, scoreboards, io);                       // Broadcast final state
    log(`Emitting game over message for ${gameID}`);
    io.to(gameID).emit('bannerMessage', 'Game over!');

    // Announce winners if any players exist
    if (scoresArray.length > 0) {
        const topScore = scoresArray[0].score;
        const winners = scoresArray.filter(p => p.score === topScore);
        if (winners.length > 1) {
            log(`Emitting multi-winner message for ${gameID}`);
            io.to(gameID).emit('bannerMessage', 'Congratulations to all the winners!');
        } else {
            log(`Emitting single winner message for ${gameID}: ${winners[0].playerName}`);
            io.to(gameID).emit('bannerMessage', `${winners[0].playerName} wins with ${winners[0].score} points!`);
        }
        io.to(gameID).emit('confetti');                             // Trigger confetti effect
    }
    
    // Clear cleanup timer if present
    if (cleanupTimeouts.has(gameID)) {
        clearTimeout(cleanupTimeouts.get(gameID));
        cleanupTimeouts.delete(gameID);
    }
}

// Check Sample Game connections for cleanup
function checkSampleGameConnections(gameID, io, cleanupTimeouts, sampleGameTimeouts, usedNames, socketBroadcast) {
    if (gameID === 'SAMPLEGAME') {
        const room = io.sockets.adapter.rooms.get(gameID);          // Get connected clients
        if (!room || room.size === 0) {                             // If no clients
            if (!cleanupTimeouts.has(gameID)) {
                scheduleCleanup(gameID, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast); // Schedule cleanup
            }
        }
    }
}

// Export all game logic functions for use in routes.js and socket.js
module.exports = {
    updateScoreboard: (gameID, playerName, scoreAdd, isNewPlayer, scoreboards, io, socketBroadcast) => 
        updateScoreboard(gameID, playerName, scoreAdd, isNewPlayer, scoreboards, io, socketBroadcast),
    startSampleGame: (gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast) => 
        startSampleGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast),
    scheduleCleanup: (gameID, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast) => 
        scheduleCleanup(gameID, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast),
    startGameTimer: (gameID, scoreboards, io, socketBroadcast, sampleGameTimeouts, usedNames, cleanupTimeouts) => 
        startGameTimer(gameID, scoreboards, io, socketBroadcast, sampleGameTimeouts, usedNames, cleanupTimeouts),
    endGame: (gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast) => 
        endGame(gameID, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, io, socketBroadcast),
    checkSampleGameConnections: (gameID, io, cleanupTimeouts, sampleGameTimeouts, usedNames, socketBroadcast) => 
        checkSampleGameConnections(gameID, io, cleanupTimeouts, sampleGameTimeouts, usedNames, socketBroadcast),
    generateHexId,
    generateUniqueName
};