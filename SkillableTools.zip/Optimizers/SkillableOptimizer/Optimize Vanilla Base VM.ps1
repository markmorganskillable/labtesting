Update-help -ErrorAction SilentlyContinue


# Clear Edge cache:

# Kill Edge process
taskkill /F /IM MicrosoftEdge.exe

# Wait for 5 seconds
Start-Sleep -s 5

# Clear Edge cache and cookies
$edgeCachePath = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache"
Remove-Item -Path $edgeCachePath -Recurse -Force

$edgeCookiesPath = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cookies"
Remove-Item -Path $edgeCookiesPath -Recurse -Force

$edgeHistoryPath = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\History"
Remove-Item -Path $edgeHistoryPath -Recurse -Force

# Disable IE Security for Admins and users

Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}' -Name IsInstalled -Value -0
Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}' -Name IsInstalled -Value -0

#Manually download and install all remaining Windows updates
Write-host "Installing Windows updates"
Start-Sleep 5

Get-WindowsUpdate -AcceptAll -Install

# Perform additional optimizations

Write-host "Perform additional optimizations (disabling lock screen and Windows Update, clearing Event logs, etc.)"
Start-Sleep 5

#Change Wallpaper Background for Current User

$Path2 = "C:\Windows\web\wallpaper\custom"
if(!(Test-Path -Path $Path2)) { 
    mkdir $Path2
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest https://github.com/LODSContent/ChallengeLabs_Resources/raw/master/Collateral/blue-gray.jpg -OutFile $Path2\blue-gray.jpg
Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name wallpaper -Value "$path2\blue-gray.jpg" 
rundll32.exe user32.dll, UpdatePerUserSystemParameters

# Disable lock screen

REG.EXE ADD HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization /f
REG.EXE ADD HKLM\SOFTWARE\Policies\Microsoft\Windows\Personalization /v NoLockScreen /t REG_DWORD /d 1 /f

#Disable Windows Update

REG.EXE ADD HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU /f
REG.EXE ADD HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU /v NoAutoUpdate /t REG_DWORD /d 1 /f

#Clear all event logs for local computer

$logs = Get-EventLog -List | ForEach-Object {$_.Log} | ForEach-Object {Clear-EventLog -LogName $_ }
Get-EventLog -list

# Set passwords to not expire (Domain Controller)
# Get-ADUser -Filter 'Name -like "*Administrator"' | Set-ADUser -PasswordNeverExpires $true

# Set admin password to not expire on local computer
Get-LocalUser -Name Admin* | Set-LocalUser -PasswordNeverExpires $true

#Configure computer to not require Ctrl+Alt+Del to sign in

Set-Itemproperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\' -Name 'DisableCAD' -Value '1'

#Disable and refuse machine password changes for domain environments

New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters' -Name 'RefusePasswordChange' -PropertyType DWORD -Value '1'
Set-Itemproperty -Path 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters' -Name 'DisablePasswordChange' -Value '1'
# Get-Item -Path 'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters' 

# Clear PowerShell history

# ([Microsoft.PowerShell.PSConsoleReadLine]::ClearHistory())
Set-PSReadlineOption -HistorySaveStyle SaveNothing
del (Get-PSReadlineOption).HistorySavePath

# Clear run history
REG.EXE delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f

# Disable network notification
REG.EXE ADD HKLM\System\CurrentControlSet\Control\Network\NewNetworkWindowOff /f

# Clear out network profiles
$NetProfiles = REG QUERY 'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles'
1..($NetProfiles.Count-1) | % {REG DELETE $NetProfiles[$_] /f}

# Set network to private  
# $NetProfile = Get-ChildItem 'HKLM:SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles' | Select-Object Name
# $NetPath = $NetProfile.TrimStart('HKEY_LOCALMACHINE\')
# Set-ItemProperty -Path ("HKLM:" + "$NetPath") -Name Category -Value 1
Get-NetConnectionProfile | Set-NetConnectionProfile -NetworkCategory Private

 # Enable Remote Desktop access  
 Set-ItemProperty -Path 'HKLM:SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 0

 # Optimize visual performance for current user.  
 Set-ItemProperty -Path 'HKCU:SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' -Name VisualFXSetting -Value 3
 Set-ItemProperty -Path 'HKCU:Control Panel\Desktop' -Name UserPreferencesMask -Value ([byte[]](0x90,0x12,0x07,0x80,0x10,0x00,0x00,0x00)) 

# Remove recent programs
Remove-Item -Force "${env:USERPROFILE}\AppData\Roaming\Microsoft\Windows\Recent\*.lnk" 

# Create firewall settings for 192.168.10.0/24 network

New-NetFirewallRule -DisplayName "Allow all 192.168.10.0/24 outbound" -Direction Outbound -Action Allow -Profile Any -LocalPort Any -RemotePort Any -Protocol Any -Program Any -LocalAddress 192.168.10.0/24 -RemoteAddress 192.168.10.0/24
New-NetFirewallRule -DisplayName "Allow all 192.168.10.0/24 inbound" -Direction Inbound -Action Allow -Profile Any -LocalPort Any -RemotePort Any -Protocol Any -Program Any -LocalAddress 192.168.10.0/24 -RemoteAddress 192.168.10.0/24

# Ensure appropriate power settings

## Set to ultimate performance (Windows 10)
# Powercfg -setactive e9a42b02-d5df-448d-aa00-03f14749eb61
## Set to high performance (Server, Windows 10)
Powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 
## Disable monitor timeout
Powercfg -change monitor-timeout-ac 0

#Optimize Edge

$OMADMPath = 'HKLM:SOFTWARE\Microsoft\Provisioning\OMADM\Accounts\FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF'
$EnrollmentPath = 'HKLM:SOFTWARE\Microsoft\Enrollments\FFFFFFFF-FFFF-FFFF-FFFF-FFFFFFFFFFFF'
$EdgePath = 'HKLM:SOFTWARE\Policies\Microsoft\Edge'

## First, create a fake MDM registration to enforce some policies on non-MDM managed/domain-joined computers

New-Item -Path $EnrollmentPath
New-ItemProperty -Path $EnrollmentPath -Name EnrollmentState -PropertyType DWORD -Value 1
New-ItemProperty -Path $EnrollmentPath -Name EnrollmentType -PropertyType DWORD -Value 0
New-ItemProperty -Path $EnrollmentPath -Name IsFederated -PropertyType DWORD -Value 0


New-Item -Path $OMADMPath
New-ItemProperty -Path $OMADMPath -Name Flags -PropertyType DWORD -Value 0x00d6fb7f
New-ItemProperty -Path $OMADMPath -Name AcctUId -PropertyType STRING -Value "0x000000000000000000000000000000000000000000000000000000000000000000000000"
New-ItemProperty -Path $OMADMPath -Name ProtoVer -PropertyType STRING -Value "1.2"
New-ItemProperty -Path $OMADMPath -Name RoamingCount -PropertyType DWORD -Value 0
New-ItemProperty -Path $OMADMPath -Name SSLClientCertReference -PropertyType STRING -Value "MY;User;0000000000000000000000000000000000000000"

## Configure Edge Settings

New-Item -Path $EdgePath
New-ItemProperty -Path $EdgePath -Name NewTabPageAllowedBackgroundTypes -PropertyType DWORD -Value 3
New-ItemProperty -Path $EdgePath -Name HomePageLocation -PropertyType STRING -Value about:blank
New-ItemProperty -Path $EdgePath -Name NewTabPageLocation -PropertyType STRING -Value about:blank
New-ItemProperty -Path $EdgePath -Name NewTabPageContentEnabled -PropertyType DWORD -Value 0
New-ItemProperty -Path $EdgePath -Name NewTabPageHideDefaultTopSites -PropertyType DWORD -Value 1
New-ItemProperty -Path $EdgePath -Name ClearBrowsingDataOnExit -PropertyType DWORD -Value 1
New-ItemProperty -Path $EdgePath -Name ConfigureDoNotTrack -PropertyType DWORD -Value 1
New-ItemProperty -Path $EdgePath -Name ShowHomeButton -PropertyType DWORD -Value 1
New-ItemProperty -Path $EdgePath -Name HideFirstRunExperience -PropertyType DWORD -Value 1
New-ItemProperty -Path $EdgePath -Name FavoritesBarEnabled -PropertyType DWORD -Value 1

 Write-Host "Script completed. The computer will now restart."

 Start-Sleep 5

 Restart-Computer -Force