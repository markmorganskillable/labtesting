/*
 * File: socket.js
 * Version: 2025-04-10_14:00:00
 * Description: This module manages Socket.IO connections and real-time updates for the Scoreboard 
 *              application. It handles client connections to specific game scoreboards, sets up 
 *              periodic update schedules based on client preferences, and broadcasts game state 
 *              changes triggered by gameLogic. It integrates with configuration settings for 
 *              logging verbosity and supports features like manual score updates, game over 
 *              notifications, and confetti effects for winners. The module ensures efficient 
 *              communication between server and clients, maintaining game state consistency 
 *              across all connected users.
 */

const configModule = require('./config');     // Configuration management module

// Logging function gated by verboseConsoleLogging config
function log(...args) {
    if (configModule.config.verboseConsoleLogging) console.log(...args);
}

// Main socket setup function, accepting dependencies as arguments
function setupSocket(io, scoreboards, clientSpeeds, cleanupTimeouts, gameLogic, sampleGameTimeouts, usedNames) {
    const updateTimeouts = new Map();         // Store timeouts for periodic client updates

    // Handle new Socket.IO connections
    io.on('connection', (socket) => {
        // Event: Client joins a scoreboard
        socket.on('joinScoreboard', (rawGameID) => {
            const gameID = rawGameID.toUpperCase();                   // Normalize gameID to uppercase
            socket.join(gameID);                                      // Add client to gameID room
            const scoreboard = scoreboards.get(gameID);               // Retrieve scoreboard
            if (!scoreboard) {
                socket.emit('scoreboardNotFound');                    // Notify client if game doesn’t exist
                return;
            }
            
            // Prepare scores array with positions
            const scoresArray = Array.from(scoreboard.scores.entries())
                .map(([playerName, score]) => ({ playerName, score })) // Convert scores to array
                .sort((a, b) => b.score - a.score);                   // Sort by score descending
            let prevScore = null;
            scoresArray.forEach((player, index) => {                   // Assign positions, handling ties
                player.position = prevScore === player.score ? scoresArray[index - 1].position : index + 1;
                prevScore = player.score;
            });
            
            // Calculate remaining time if timer exists
            const timeLeft = scoreboard.timerEnd ? Math.max(0, Math.floor((scoreboard.timerEnd - Date.now()) / 1000)) : null;
            log(`New viewer joined ${scoreboard.gameOver ? 'ended' : 'running'} game ${gameID}`);
            
            // Send initial game state to client
            socket.emit('update', { 
                scores: scoresArray, 
                name: scoreboard.name, 
                timer: scoreboard.timer, 
                timeLeft: timeLeft,
                verboseClientLogging: configModule.config.verboseClientLogging // Send client logging setting
            });
            
            // Send initial banner message based on game state
            socket.emit('bannerMessage', scoresArray.length > 0 ? 'Game in progress...' : 'Waiting for players...');
            
            // If game is over, send end notifications
            if (scoreboard.gameOver) {
                socket.emit('gameOver');                               // Notify game over
                socket.emit('bannerMessage', 'Game over!');            // Announce end
                if (scoresArray.length > 0) {
                    const topScore = scoresArray[0].score;
                    const winners = scoresArray.filter(p => p.score === topScore); // Find all top scorers
                    if (winners.length > 1) {
                        socket.emit('bannerMessage', 'Congratulations to all the winners!');
                    } else {
                        socket.emit('bannerMessage', `${winners[0].playerName} wins with ${winners[0].score} points!`);
                    }
                    socket.emit('confetti');                           // Trigger confetti effect
                }
            }
        });

        // Event: Client sets update speed for periodic updates
        socket.on('setUpdateSpeed', ({ gameID: rawGameID, speed }) => {
            const gameID = rawGameID.toUpperCase();
            const scoreboard = scoreboards.get(gameID);
            if (!scoreboard || scoreboard.gameOver) return;            // Ignore if game doesn’t exist or is over
            
            // Clamp speed between 1s and 15s, allow 0 for manual mode
            const clampedSpeed = speed === 0 ? 0 : Math.min(Math.max(1000, speed), 15000);
            clientSpeeds.set(socket.id, { gameID, speed: clampedSpeed }); // Store client’s speed preference
            log(`Client ${socket.id} set speed to ${clampedSpeed}ms for ${gameID}`);
            scheduleUpdate(socket.id, gameID, clampedSpeed, io);       // Schedule periodic updates
        });

        // Event: Client requests manual score update
        socket.on('getScores', (rawGameID) => {
            const gameID = rawGameID.toUpperCase();
            const scoreboard = scoreboards.get(gameID);
            if (!scoreboard || scoreboard.gameOver) return;            // Ignore if game doesn’t exist or is over
            
            // Prepare scores array with positions
            const scoresArray = Array.from(scoreboard.scores.entries())
                .map(([playerName, score]) => ({ playerName, score }))
                .sort((a, b) => b.score - a.score);
            let prevScore = null;
            scoresArray.forEach((player, index) => {
                player.position = prevScore === player.score ? scoresArray[index - 1].position : index + 1;
                prevScore = player.score;
            });
            
            // Calculate remaining time
            const timeLeft = scoreboard.timerEnd ? Math.max(0, Math.floor((scoreboard.timerEnd - Date.now()) / 1000)) : null;
            
            // Send updated state to client
            socket.emit('update', { 
                scores: scoresArray, 
                name: scoreboard.name, 
                timer: scoreboard.timer, 
                timeLeft: timeLeft,
                verboseClientLogging: configModule.config.verboseClientLogging
            });
            log(`Manual update sent to client ${socket.id} for ${gameID}`);
        });

        // Event: Client disconnects
        socket.on('disconnect', () => {
            if (updateTimeouts.has(socket.id)) {                       // Clear any scheduled updates
                clearTimeout(updateTimeouts.get(socket.id));
                updateTimeouts.delete(socket.id);
            }
            const clientSpeed = clientSpeeds.get(socket.id);           // Get client’s gameID
            const gameID = clientSpeed?.gameID;
            clientSpeeds.delete(socket.id);                            // Remove client speed preference
            
            // Check if Sample Game needs cleanup on disconnect
            if (gameID === 'SAMPLEGAME') {
                gameLogic.checkSampleGameConnections(gameID, io, cleanupTimeouts, sampleGameTimeouts, usedNames, broadcastScoreboardUpdate);
            }
        });
    });

    // Broadcast scoreboard updates to all clients in a game room
    function broadcastScoreboardUpdate(gameID, scoreboards, io) {
        const scoreboard = scoreboards.get(gameID);
        if (!scoreboard || scoreboard.gameOver) return;                // Skip if game doesn’t exist or is over
        
        // Prepare scores array with positions
        const scoresArray = Array.from(scoreboard.scores.entries())
            .map(([playerName, score]) => ({ playerName, score }))
            .sort((a, b) => b.score - a.score);
        let prevScore = null;
        scoresArray.forEach((player, index) => {
            player.position = prevScore === player.score ? scoresArray[index - 1].position : index + 1;
            prevScore = player.score;
        });
        
        // Calculate remaining time
        const timeLeft = scoreboard.timerEnd ? Math.max(0, Math.floor((scoreboard.timerEnd - Date.now()) / 1000)) : null;
        log(`Broadcasting scores for ${gameID}:`, JSON.stringify(scoresArray));
        
        // Send update to all clients in the game room
        io.to(gameID).emit('update', { 
            scores: scoresArray, 
            name: scoreboard.name, 
            timer: scoreboard.timer, 
            timeLeft: timeLeft,
            verboseClientLogging: configModule.config.verboseClientLogging
        });
    }

    // Schedule periodic updates for a client based on their speed preference
    function scheduleUpdate(socketId, gameID, speed, io) {
        if (updateTimeouts.has(socketId)) {                           // Clear existing timeout
            clearTimeout(updateTimeouts.get(socketId));
            updateTimeouts.delete(socketId);
        }

        if (speed === 0) {                                            // Manual mode—no auto-updates
            log(`Client ${socketId} switched to manual mode (speed 0) for ${gameID}`);
            return;
        }

        // Recursive update function
        function runUpdate() {
            // Check if client is still connected to the game room
            if (io.sockets.sockets.get(socketId)?.rooms.has(gameID)) {
                broadcastScoreboardUpdate(gameID, scoreboards, io);   // Broadcast current state
                const timeoutId = setTimeout(runUpdate, speed);       // Schedule next update
                updateTimeouts.set(socketId, timeoutId);              // Store timeout
            } else {
                updateTimeouts.delete(socketId);                      // Clean up if disconnected
            }
        }

        const timeoutId = setTimeout(runUpdate, speed);               // Start update cycle
        updateTimeouts.set(socketId, timeoutId);
    }

    // Return broadcast function for use in gameLogic.js
    return { broadcastScoreboardUpdate };
}

// Export the setupSocket function for use in server.js
module.exports = setupSocket;