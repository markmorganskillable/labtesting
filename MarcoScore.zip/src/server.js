/*
 * File: server.js
 * Version: 2025-04-10_12:00:00
 * Description: This is the main entry point for the Scoreboard application, a real-time web-based game 
 *              server built with Express and Socket.IO. It initializes the HTTP server, sets up 
 *              middleware for handling requests and sessions, loads configuration from config.json, 
 *              and wires up game logic and socket communication. The server manages scoreboard state, 
 *              handles client connections, and supports admin configuration via a web interface. 
 *              Command-line arguments can override config settings, and all game state is stored 
 *              in-memory for simplicity and speed.
 */

// Import core Node.js modules for building the server
const express = require('express');           // Web framework for routing and middleware
const http = require('http');                 // Core HTTP server module
const socketIo = require('socket.io');        // WebSocket library for real-time communication
const path = require('path');                 // Utility for handling file paths
const session = require('express-session');   // Middleware for session management

// Wrap server startup in an async IIFE to handle asynchronous config loading
(async () => {
    // Load the config module, which manages config.json loading and saving
    const configModule = require('./config');
    
    // Await the config load to ensure configModule.config is populated before proceeding
    // This prevents race conditions where config values are accessed before they're set
    await configModule.loadConfig();

    // Initialize Express app instance
    const app = express();
    
    // Create an HTTP server instance using the Express app
    const server = http.createServer(app);
    
    // Initialize Socket.IO for real-time communication, attaching it to the HTTP server
    const io = socketIo(server);

    // Middleware setup
    app.use(express.json());                  // Parse incoming JSON request bodies
    app.use(express.static(path.join(__dirname, '../public'))); // Serve static files from /public
    app.use(session({                         // Configure session middleware for admin authentication
        secret: 'scoreboard-secret-key',      // Secret for signing session cookies (change in production)
        resave: false,                        // Don’t resave unchanged sessions
        saveUninitialized: false,             // Don’t save uninitialized sessions
        cookie: { secure: false }             // Non-secure cookie for local dev (set true for HTTPS)
    }));
    app.use((req, res, next) => {             // Set Content-Language header for all responses
        res.setHeader('Content-Language', 'en');
        next();
    });

    // Initialize in-memory data structures for game state
    const scoreboards = new Map();            // Store active scoreboards (gameID -> scoreboard object)
    const clientSpeeds = new Map();           // Track client update speeds (socketID -> { gameID, speed })
    const sampleGameTimeouts = new Map();     // Store timeouts for Sample Game actions
    const usedNames = new Map();              // Track used player names per game (gameID -> Set)
    const cleanupTimeouts = new Map();        // Store cleanup timers for inactive games

    // Load additional modules after config is ready
    const socketModule = require('./socket'); // Socket.IO logic for real-time updates
    const gameLogic = require('./gameLogic'); // Game mechanics and logic

    // Parse command-line arguments for overrides
    const args = process.argv.slice(2);
    const portArg = args.find(arg => arg.startsWith('--port='));
    const adminPassArg = args.find(arg => arg.startsWith('--admin-pass='));
    
    // Set PORT, preferring CLI arg over config value
    const PORT = portArg ? parseInt(portArg.split('=')[1], 10) : configModule.config.port;

    // Override admin password if provided via CLI and save to config
    if (adminPassArg) {
        configModule.config.adminPassword = adminPassArg.split('=')[1];
        console.log(`Admin password overridden by CLI to: ${configModule.config.adminPassword}`);
        await configModule.saveConfig(configModule.config); // Persist CLI override to config.json
    }

    // Log the full config state after setup for debugging
    console.log(`Config after setup:`, configModule.config);
    
    // Log the admin password explicitly—used for login verification
    console.log(`Admin password set to: ${configModule.config.adminPassword}`);

    // Initialize Socket.IO handlers with dependencies
    const socket = socketModule(io, scoreboards, clientSpeeds, cleanupTimeouts, gameLogic, sampleGameTimeouts, usedNames);
    
    // Set up HTTP routes with dependencies, passing a getter for admin password
    const routes = require('./routes');
    routes(app, io, scoreboards, sampleGameTimeouts, usedNames, cleanupTimeouts, gameLogic, configModule, 
           () => configModule.config.adminPassword, socket.broadcastScoreboardUpdate);

    // Start the server on the specified port
    server.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
    });
})();